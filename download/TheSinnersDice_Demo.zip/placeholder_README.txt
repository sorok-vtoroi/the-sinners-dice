PLACEHOLDER

Замените этот архив на реальный ZIP-билд демоверсии.
Файл должен называться: TheSinnersDice_Demo.zip
Путь для сайта: download/TheSinnersDice_Demo.zip
